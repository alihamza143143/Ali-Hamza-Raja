We tried to implement what we drawn in our initial sketch .Due to high workload of my software house and other subjects as well , i was just able to create what you can see now.
Instead of opening it on Chrome browser Edge is more recommended !
Regards
Raja Ali Hamaza Tariq 